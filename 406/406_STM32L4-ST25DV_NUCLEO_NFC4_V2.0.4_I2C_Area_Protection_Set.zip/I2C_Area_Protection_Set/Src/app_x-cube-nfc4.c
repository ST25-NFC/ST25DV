/**
  ******************************************************************************
  * File Name          :  stmicroelectronics_x-cube-nfc4_1_5_2.c
  * Description        : This file provides code for the configuration
  *                      of the STMicroelectronics.X-CUBE-NFC4.1.5.2 instances.
  ******************************************************************************
  *
  * COPYRIGHT 2020 STMicroelectronics
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software 
  * distributed under the License is distributed on an "AS IS" BASIS, 
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  ******************************************************************************
  */

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/

#include "main.h"

/* Includes ------------------------------------------------------------------*/
#include "app_x-cube-nfc4.h"
#include "nfc04a1_nfctag.h"
#include "stm32l4xx_nucleo.h"
#include <stdio.h>
#include <string.h>	

/** @defgroup ST25_Nucleo
  * @{
  */

/** @defgroup Main
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Global variables ----------------------------------------------------------*/
UART_HandleTypeDef huart;
char uartmsg[80];
uint8_t writedata = 0xAA;
uint8_t readdata = 0x0;
uint8_t cnt = 0;
uint32_t st25dvbmsize = 0;
uint32_t memindex = 0;
ST25DV_PASSWD passwd;
ST25DV_I2CSSO_STATUS i2csso;
ST25DV_MEM_SIZE st25dvmemsize;
uint32_t ret;
extern UART_HandleTypeDef hcom_uart[COMn];
/* Private functions ---------------------------------------------------------*/
void MX_NFC4_I2CProtection_Init(void);
void MX_NFC4_I2CProtection_Process(void);

HAL_StatusTypeDef UARTConsolePrint( char *puartmsg );
HAL_StatusTypeDef UARTConsoleScan( uint8_t uartchar );

void MX_NFC_Init(void)
{
  /* USER CODE BEGIN SV */ 

  /* USER CODE END SV */

  /* USER CODE BEGIN NFC4_Library_Init_PreTreatment */
  
  /* USER CODE END NFC4_Library_Init_PreTreatment */

  /* Initialize the peripherals and the NFC4 components */

  MX_NFC4_I2CProtection_Init();

  /* USER CODE BEGIN SV */ 

  /* USER CODE END SV */
  
  /* USER CODE BEGIN NFC4_Library_Init_PostTreatment */
  
  /* USER CODE END NFC4_Library_Init_PostTreatment */
}
/*
 * LM background task
 */
void MX_NFC_Process(void)
{
  /* USER CODE BEGIN NFC4_Library_Process */

  MX_NFC4_I2CProtection_Process();
  
  
  
  /* USER CODE END NFC4_Library_Process */
}

/**
  * @brief  Initialize the I2CProtection  feature Example
  * @retval None
  */
void MX_NFC4_I2CProtection_Init(void)
{
  /* Init of the Leds on X-NUCLEO-NFC04A1 board */
  NFC04A1_LED_Init(GREEN_LED);
  NFC04A1_LED_Init(BLUE_LED);
  NFC04A1_LED_Init(YELLOW_LED);

  NFC04A1_LED_On( GREEN_LED );
  HAL_Delay( 300 );
  NFC04A1_LED_On( BLUE_LED );
  HAL_Delay( 300 );
  NFC04A1_LED_On( YELLOW_LED );
  HAL_Delay( 300 );
  
 /* Init ST25DV driver */
  while( NFC04A1_NFCTAG_Init(NFC04A1_NFCTAG_INSTANCE) != NFCTAG_OK );
  
  /* Init done */
  NFC04A1_LED_Off( GREEN_LED );
  HAL_Delay( 300 );
  NFC04A1_LED_Off( BLUE_LED );
  HAL_Delay( 300 );
  NFC04A1_LED_Off( YELLOW_LED );
  HAL_Delay( 300 );
  
	/* Init UART for display message on console */
  BSP_COM_Init(COM1);	
  
	/* Reset Mailbox enable to allow write to EEPROM */
  NFC04A1_NFCTAG_ResetMBEN_Dyn(NFC04A1_NFCTAG_INSTANCE);
	
	/* You need to present password to change static configuration */
  NFC04A1_NFCTAG_ReadI2CSecuritySession_Dyn(NFC04A1_NFCTAG_INSTANCE, &i2csso);
	
  if( i2csso == ST25DV_SESSION_CLOSED )
	{
     /* if I2C session is closed, present password to open session */
     passwd.MsbPasswd = 0;
     passwd.LsbPasswd = 0;
     NFC04A1_NFCTAG_PresentI2CPassword(NFC04A1_NFCTAG_INSTANCE, passwd);
		 UARTConsolePrint( "\n\r\n\rPassword presented to open I2C session!" );		
	}
	
	/*Write protected zone 1*/
	ret=NFC04A1_NFCTAG_WriteI2CProtectZonex(NFC04A1_NFCTAG_INSTANCE, ST25DV_PROT_ZONE1,  ST25DV_WRITE_PROT );
	if(ret==NFCTAG_OK) 
	{
		UARTConsolePrint( "\n\rZone 1 is wirte protected" );
	}
	
//	UARTConsolePrint( "\n\rZone 2 is write protected" );
//	/*Protect zone 2 for i2c write without password */
//	NFC04A1_NFCTAG_WriteI2CProtectZonex(NFC04A1_NFCTAG_INSTANCE, ST25DV_PROT_ZONE2,  ST25DV_WRITE_PROT );
//	
//	UARTConsolePrint( "\n\rZone 3 is read protected" );
//	/* Protect zone 3 for i2c read without password */
//	NFC04A1_NFCTAG_WriteI2CProtectZonex(NFC04A1_NFCTAG_INSTANCE, ST25DV_PROT_ZONE3,  ST25DV_READ_PROT );
//	
//	UARTConsolePrint( "\n\rZone 4 is read/write protected" );
//	/* Protect zone 4 for i2c read and write without password */
//	NFC04A1_NFCTAG_WriteI2CProtectZonex(NFC04A1_NFCTAG_INSTANCE, ST25DV_PROT_ZONE4,  ST25DV_READWRITE_PROT );
}

  /**
  * @brief  Process of the I2CProtection application
  * @retval None
  */
void MX_NFC4_I2CProtection_Process(void)
{
 
}

/**
 * @brief   This function sends data on the uart
 * @param   puartmsg: 
 * @retval  HAL_StatusTypeDef
 */
HAL_StatusTypeDef UARTConsolePrint( char *puartmsg )
{
  return HAL_UART_Transmit( &hcom_uart[COM1], (uint8_t *)puartmsg, strlen( puartmsg ), 500);
}

/**
 * @brief   This function wait a data on the uart
 * @param   uartchar received character
 * @retval  HAL_StatusTypeDef
 */
HAL_StatusTypeDef UARTConsoleScan( uint8_t uartchar )
{
  while( HAL_UART_Receive( &hcom_uart[COM1], &uartchar, 1, 500) == HAL_TIMEOUT );
  
  return HAL_OK;
}

#ifdef __cplusplus
}
#endif

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
