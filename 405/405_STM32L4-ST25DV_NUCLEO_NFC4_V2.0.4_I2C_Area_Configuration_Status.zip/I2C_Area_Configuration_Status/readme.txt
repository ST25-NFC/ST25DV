/**
  @page I2C Protection Readme file
  
  @verbatim
  ******************** (C) COPYRIGHT 2017 STMicroelectronics *******************
  * @file    readme.txt 
  * @author  MMY Application Team
  * @version	v1.2.0
  * @date	11-July-2018
  * @brief   This application read/write NDEF message.
  ******************************************************************************
  *
  *
  * <h2><center>&copy; COPYRIGHT 2016 STMicroelectronics</center></h2>
  *
  * Licensed under ST MYLIBERTY SOFTWARE LICENSE AGREEMENT (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/myliberty  
  *
  * Unless required by applicable law or agreed to in writing, software 
  * distributed under the License is distributed on an "AS IS" BASIS, 
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied,
  * AND SPECIFICALLY DISCLAIMING THE IMPLIED WARRANTIES OF MERCHANTABILITY,
  * FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  *
  ******************************************************************************
  @endverbatim

@par Description

This directory contains a set of source files that implement a simple example based on 
ST25DV's I2C Protection feature.

@note Care must be taken when using HAL_Delay(), this function provides accurate delay (in milliseconds)
      based on variable incremented in SysTick ISR. This implies that if HAL_Delay() is called from
      a peripheral ISR process, then the SysTick interrupt must have higher priority (numerically lower)
      than the peripheral interrupt. Otherwise the caller ISR process will be blocked.
      To change the SysTick interrupt priority you have to use HAL_NVIC_SetPriority() function.

@note The application need to ensure that the SysTick time base is always set to 1 millisecond
      to have correct HAL operation.

@par Directory contents 

  - main.h                   Main config file
  - stm32xxxx_hal_conf.h     Library Configuration file
  - stm32xxxx_it.h           Header for stm32xxxx_it.c
  - main.c                   Main program file
  - stm32xxxx_it.c           STM32xxxx Interrupt handlers
  - system_stm32xxxx.c       STM32xxxx system file

@par Hardware and Software environment  

  - This example runs on STM32L053R8,STM32L476RG and STM32F401RE devices.
    
  - This application has been tested with STMicroelectronics:
    STM32L0xx-Nucleo RevC
    STM32F4xx-Nucleo RevC
    STM32L4xx-Nucleo RevC
    boards and can be easily tailored to any other supported device 
    and development board.

  - STM32LXxx-Nucleo and STM32FXxx-Nucleo RevC Set-up    
    - Connect the Nucleo board to your PC with a USB cable type A to mini-B 
      to ST-LINK connector (CN1).
    - Please ensure that the ST-LINK connector CN2 jumpers are fitted.

        
    
@par How to use it ? 

this example code is based on en.x-cube-nfc4(STM32CubeExpansion_NFC4_V2.0.4), IDE used is Keil V5.

To execute the example code, please follow the following procedure:

1. Please download the sourecode on the ST website(ST account needed):
https://www.st.com/content/st_com/en/products/ecosystems/stm32-open-development-environment/stm32-nucleo-expansion-boards/stm32-ode-connect-hw/x-nucleo-nfc04a1.html#tools-software

2. Unzip the folder to get STM32CubeExpansion_NFC4_V2.0.4 original version

3. Unzip the example code and copied it to the example folder(eg..\...\STM32CubeExpansion_NFC4_V2.0.4\Projects\STM32L476RG-Nucleo\Examples\xxxx)

4. Rebuild all the project and enjoy!

 * <h3><center>&copy; COPYRIGHT STMicroelectronics</center></h3>
 */
