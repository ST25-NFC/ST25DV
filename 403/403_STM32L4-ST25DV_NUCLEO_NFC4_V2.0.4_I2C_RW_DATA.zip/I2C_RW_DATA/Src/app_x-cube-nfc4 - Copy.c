/**
  ******************************************************************************
  * File Name          :  stmicroelectronics_x-cube-nfc4_1_5_2.c
  * Description        : This file provides code for the configuration
  *                      of the STMicroelectronics.X-CUBE-NFC4.1.5.2 instances.
  ******************************************************************************
  *
  * COPYRIGHT 2020 STMicroelectronics
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software 
  * distributed under the License is distributed on an "AS IS" BASIS, 
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  ******************************************************************************
  */

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/

#include "main.h"

/* Includes ------------------------------------------------------------------*/
#include "app_x-cube-nfc4.h"
#include "nfc04a1_nfctag.h"
#include "stm32l4xx_nucleo.h"
#include <stdio.h>
#include <string.h>	

/** @defgroup ST25_Nucleo
  * @{
  */

/** @defgroup Main
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Global variables ----------------------------------------------------------*/
UART_HandleTypeDef huart;
char uartmsg[80];
//uint8_t writedata = 0xAA;
//uint8_t readdata = 0x0;
//uint8_t cnt = 0;
//uint32_t st25dvbmsize = 0;
//uint32_t memindex = 0;
ST25DV_PASSWD passwd;
ST25DV_I2CSSO_STATUS i2csso;
ST25DV_MEM_SIZE st25dvmemsize;
uint32_t ret;
extern UART_HandleTypeDef hcom_uart[COMn];

/* Private functions ---------------------------------------------------------*/

void MX_NFC4_I2C_RW_DATA_Init(void);
void MX_NFC4_I2C_RW_DATA_Process(void);


HAL_StatusTypeDef UARTConsolePrint( char *puartmsg );
HAL_StatusTypeDef UARTConsoleScan( uint8_t uartchar );

void MX_NFC_Init(void)
{
  /* USER CODE BEGIN SV */ 

  /* USER CODE END SV */

  /* USER CODE BEGIN NFC4_Library_Init_PreTreatment */
  
  /* USER CODE END NFC4_Library_Init_PreTreatment */

  /* Initialize the peripherals and the NFC4 components */

  MX_NFC4_I2C_RW_DATA_Init();
	
  MX_NFC4_I2C_RW_DATA_Process();
  

  /* USER CODE BEGIN SV */ 

  /* USER CODE END SV */
  
  /* USER CODE BEGIN NFC4_Library_Init_PostTreatment */
  
  /* USER CODE END NFC4_Library_Init_PostTreatment */
}
/*
 * LM background task
 */
void MX_NFC_Process(void)
{
  /* USER CODE BEGIN NFC4_Library_Process */
 
  /* USER CODE END NFC4_Library_Process */
}


  /**
  * @brief  Initialize the NFC4 I2C data read/ write Example
  * @retval None
  */
void MX_NFC4_I2C_RW_DATA_Init(void)
{
  /* Init of the Leds on X-NUCLEO-NFC04A1 board */
  NFC04A1_LED_Init(GREEN_LED);
  NFC04A1_LED_Init(BLUE_LED);
  NFC04A1_LED_Init(YELLOW_LED);

  NFC04A1_LED_On( GREEN_LED );
  HAL_Delay( 300 );
  NFC04A1_LED_On( BLUE_LED );
  HAL_Delay( 300 );
  NFC04A1_LED_On( YELLOW_LED );
  HAL_Delay( 300 );
  
 /* Init ST25DV driver */
  while( NFC04A1_NFCTAG_Init(NFC04A1_NFCTAG_INSTANCE) != NFCTAG_OK );
  
  /* Init done */
  NFC04A1_LED_Off( GREEN_LED );
  HAL_Delay( 300 );
  NFC04A1_LED_Off( BLUE_LED );
  HAL_Delay( 300 );
  NFC04A1_LED_Off( YELLOW_LED );
  HAL_Delay( 300 );
  
	/* Init UART for display message on console */
  BSP_COM_Init(COM1);	
  
  UARTConsolePrint( "\n\r----------------------------------------" );
  UARTConsolePrint( "\n\r*****Welcome to x-cube-nfc4 example*****" );
  UARTConsolePrint( "\n\r----------------------------------------" );
}

   /**
  * @brief  Process of the NFC4 I2C data read/ write Example
  * @retval None
  */
void MX_NFC4_I2C_RW_DATA_Process(void)
{
	uint16_t nbbytes=1;
	uint16_t reg_addr = ST25DV_ENDA3_REG;
	uint16_t EEprom_addr=500;
	uint8_t readdata=0;
	uint8_t writedata = 0xAA;
	ST25DV_I2C_PROT_ZONE pProtZone;
	ST25DV_PROTECTION_CONF Status_prot;
	ST25DV_END_ZONE end_zone;
  uint8_t end_addr;
	
//	pProtZone->ProtectZone1= ST25DV_NO_PROT;
		pProtZone.ProtectZone2 = ST25DV_NO_PROT;
//	pProtZone->ProtectZone3= ST25DV_NO_PROT;
//	pProtZone->ProtectZone4= ST25DV_NO_PROT;
//	
  /* You need to present password before changing static configuration */
  NFC04A1_NFCTAG_ReadI2CSecuritySession_Dyn(NFC04A1_NFCTAG_INSTANCE, &i2csso );
  if( i2csso == ST25DV_SESSION_CLOSED )
  {
    /* if I2C session is closed, present password to open session */
    passwd.MsbPasswd = 0; /* Default value for password */
    passwd.LsbPasswd = 0; /* change it if password has been modified */
    NFC04A1_NFCTAG_PresentI2CPassword(NFC04A1_NFCTAG_INSTANCE, passwd );
		UARTConsolePrint( "Password Presented" );
	}	
		
	NFC04A1_NFCTAG_ReadRegister(NFC04A1_NFCTAG_INSTANCE,&readdata,reg_addr,1);//NFC04A1_NFCTAG_ReadRegister only allow to read static register
	sprintf( uartmsg, "\n\r\n\rReg Addr: %d\n\r , data: %X", reg_addr, readdata );
  UARTConsolePrint( uartmsg );	

	ret = NFC04A1_NFCTAG_ReadI2CProtectZone( NFC04A1_NFCTAG_INSTANCE, &pProtZone );
	Status_prot = pProtZone.ProtectZone2; 	
	
	switch( Status_prot )
  {
    case ST25DV_NO_PROT:
			UARTConsolePrint( "\n\r\n\rRead allowed, write allowed!" );
      break;
    case ST25DV_WRITE_PROT:
			UARTConsolePrint( "\n\r\n\rRead allowed, write not allowed unless password presented!!!" );
		
			NFC04A1_NFCTAG_ReadEndZonex(NFC04A1_NFCTAG_INSTANCE, ST25DV_ZONE_END3, &end_addr);
		
			sprintf( uartmsg, "\n\r\n\rST25DV_ZONE_END2 @0x%X ",end_addr );
			UARTConsolePrint( uartmsg );			
		
      break;
    case ST25DV_READ_PROT:
			UARTConsolePrint( "\n\r\n\rRead not allowed unless password presented, write allowed!!!" );
      break;
    case ST25DV_READWRITE_PROT:
			UARTConsolePrint( "\n\r\n\rRead not allowed unless password presented, write not allowed unless password presented!!!" );
      break;
    
    default:
      break;
  }


	ret = NFC04A1_NFCTAG_WriteData(NFC04A1_NFCTAG_INSTANCE, &writedata, EEprom_addr, 1 );
	
	if( ret != NFCTAG_OK )
	{
		sprintf( uartmsg, "\n\r\n\r Write data protected, need i2c password");
		UARTConsolePrint( uartmsg );
	}
	else
	{
		sprintf( uartmsg, "\n\r\n\r Writedata done" );
		UARTConsolePrint( uartmsg );
	}

	/* Read EEPROM */
	ret = NFC04A1_NFCTAG_ReadData(NFC04A1_NFCTAG_INSTANCE, &readdata, EEprom_addr, nbbytes );
//  if( readdata == 0xFF )
//	{
//     sprintf( uartmsg, "\n\rRead Zone  protected, need i2c password" );
//     UARTConsolePrint( uartmsg );
//  }
//  else
//  {
		sprintf( uartmsg, "\n\r Addr: %d , data: %X ", EEprom_addr,readdata );
    UARTConsolePrint( uartmsg );
//  }
}

/**
 * @brief   This function sends data on the uart
 * @param   puartmsg: 
 * @retval  HAL_StatusTypeDef
 */
HAL_StatusTypeDef UARTConsolePrint( char *puartmsg )
{
  return HAL_UART_Transmit( &hcom_uart[COM1], (uint8_t *)puartmsg, strlen( puartmsg ), 500);
}

/**
 * @brief   This function wait a data on the uart
 * @param   uartchar received character
 * @retval  HAL_StatusTypeDef
 */
HAL_StatusTypeDef UARTConsoleScan( uint8_t uartchar )
{
  while( HAL_UART_Receive( &hcom_uart[COM1], &uartchar, 1, 500) == HAL_TIMEOUT );
  
  return HAL_OK;
}

#ifdef __cplusplus
}
#endif


/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
