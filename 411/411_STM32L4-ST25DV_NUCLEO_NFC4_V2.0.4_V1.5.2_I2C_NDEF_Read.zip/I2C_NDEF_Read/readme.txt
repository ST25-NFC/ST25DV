This example shows how to read Ndef message through I2C interface. 

this example code is based on en.x-cube-nfc4(STM32CubeExpansion_NFC4_V2.0.4), IDE used is Keil V5.

To execute the example code, please follow the following procedure:

1. Please download the sourecode on the ST website(ST account needed):
https://www.st.com/content/st_com/en/products/ecosystems/stm32-open-development-environment/stm32-nucleo-expansion-boards/stm32-ode-connect-hw/x-nucleo-nfc04a1.html#tools-software

2. Unzip the folder to get STM32CubeExpansion_NFC4_V2.0.4 original version

3. Unzip the example code and copied it to the example folder(eg..\...\STM32CubeExpansion_NFC4_V2.0.4\Projects\STM32L476RG-Nucleo\Examples\xxxx)

4. Rebuild all the project and enjoy!