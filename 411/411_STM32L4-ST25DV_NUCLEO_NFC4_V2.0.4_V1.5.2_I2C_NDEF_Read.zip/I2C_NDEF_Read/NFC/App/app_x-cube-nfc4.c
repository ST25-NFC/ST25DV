/**
  ******************************************************************************
  * File Name          :  stmicroelectronics_x-cube-nfc4_1_5_2.c
  * Description        : This file provides code for the configuration
  *                      of the STMicroelectronics.X-CUBE-NFC4.1.5.2 instances.
  ******************************************************************************
  *
  * COPYRIGHT 2020 STMicroelectronics
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software 
  * distributed under the License is distributed on an "AS IS" BASIS, 
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  ******************************************************************************
  */

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/

#include "main.h"

/* Includes ------------------------------------------------------------------*/
#include "app_x-cube-nfc4.h"
#include "common.h"
#include "tagtype5_wrapper.h"
#include "lib_NDEF_Wifi.h"
#include "ndef_message.h"
#include "ndef_types_rtd.h"
#include "ndef_dump.h"
#include "stm32l4xx_nucleo.h"
#include "nfc04a1_nfctag.h"

/** @defgroup ST25_Nucleo
  * @{
  */

/** @defgroup Main
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Global variables ----------------------------------------------------------*/
UART_HandleTypeDef huart;
char uartmsg[80];
static	uint8_t    rawMessageBuf[ST25DV_NDEF_MAX_SIZE];
uint32_t st25dvbmsize = 0;
ST25DV_PASSWD passwd;
ST25DV_I2CSSO_STATUS i2csso;
ST25DV_MEM_SIZE st25dvmemsize;
uint32_t ret;
extern UART_HandleTypeDef hcom_uart[COMn];


/*! NDEF states  */
typedef enum {
    NDEF_STATE_INVALID     = 0x00U,                            /*!< Invalid state (e.g. no CC)                         */
    NDEF_STATE_INITIALIZED = 0x01U,                            /*!< State Initialized (no NDEF message)                */
    NDEF_STATE_READWRITE   = 0x02U,                            /*!< Valid NDEF found. Read/Write capability            */
    NDEF_STATE_READONLY    = 0x03U,                            /*!< Valid NDEF found. Read only                        */
} ndefState;
typedef struct {
    uint8_t                  majorVersion;                     /*!< Major version                                      */
    uint8_t                  minorVersion;                     /*!< Minor version                                      */
    uint32_t                 areaLen;                          /*!< Area Len for NDEF storage                          */
    uint32_t                 areaAvalableSpaceLen;             /*!< Remaining Space in case a propTLV is present       */
    uint32_t                 messageLen;                       /*!< NDEF message Len                                   */
    ndefState                state;                            /*!< Tag state e.g. NDEF_STATE_INITIALIZED              */
} ndefInfo;
/* Private define ------------------------------------------------------------*/
static bool                 verbose             = true;
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Global variables ----------------------------------------------------------*/
//sURI_Info URI;
//Ndef_Bluetooth_OOB_t BLEPairing;
extern sCCFileInfo CCFileStruct;

/* Private functions ---------------------------------------------------------*/

void MX_NFC4_I2C_RW_DATA_Init(void);
void MX_NFC4_I2C_RW_DATA_Process(void);


void MX_NFC_Init(void)
{
  /* USER CODE BEGIN SV */ 

  /* USER CODE END SV */

  /* USER CODE BEGIN NFC4_Library_Init_PreTreatment */
  
  /* USER CODE END NFC4_Library_Init_PreTreatment */

  /* Initialize the peripherals and the NFC4 components */

  MX_NFC4_I2C_RW_DATA_Init();
	
  MX_NFC4_I2C_RW_DATA_Process();
  

  /* USER CODE BEGIN SV */ 

  /* USER CODE END SV */
  
  /* USER CODE BEGIN NFC4_Library_Init_PostTreatment */
  
  /* USER CODE END NFC4_Library_Init_PostTreatment */
}
/*
 * LM background task
 */
void MX_NFC_Process(void)
{
  /* USER CODE BEGIN NFC4_Library_Process */
    if( platformGpioIsLow(PLATFORM_USER_BUTTON_PORT, PLATFORM_USER_BUTTON_PIN))
    {

				MX_NFC4_I2C_RW_DATA_Process();
        /* Debounce button */
        while( platformGpioIsLow(PLATFORM_USER_BUTTON_PORT, PLATFORM_USER_BUTTON_PIN) );
    } 
  /* USER CODE END NFC4_Library_Process */
}


  /**
  * @brief  Initialize the NFC4 I2C data read/ write Example
  * @retval None
  */
void MX_NFC4_I2C_RW_DATA_Init(void)
{

  /* Init of the Leds on X-NUCLEO-NFC04A1 board */
  NFC04A1_LED_Init(GREEN_LED);
  NFC04A1_LED_Init(BLUE_LED);
  NFC04A1_LED_Init(YELLOW_LED);

  NFC04A1_LED_On( GREEN_LED );
  HAL_Delay( 300 );
  NFC04A1_LED_On( BLUE_LED );
  HAL_Delay( 300 );
  NFC04A1_LED_On( YELLOW_LED );
  HAL_Delay( 300 );
  
 /* Init ST25DV driver */
  while( NFC04A1_NFCTAG_Init(NFC04A1_NFCTAG_INSTANCE) != NFCTAG_OK );
  
  /* Init done */
  NFC04A1_LED_Off( GREEN_LED );
  HAL_Delay( 300 );
  NFC04A1_LED_Off( BLUE_LED );
  HAL_Delay( 300 );
  NFC04A1_LED_Off( YELLOW_LED );
  HAL_Delay( 300 );
  
	/* Init UART for display message on console */
  BSP_COM_Init(COM1);	
	//logUsartInit(&huart2);
  
  platformLog( "\n\r----------------------------------------" );
  platformLog( "\n\r*****Welcome to x-cube-nfc4 example*****" );
  platformLog( "\n\r----------------------------------------\n\r" );
	
}

   /**
  * @brief  Process of the NFC4 I2C data read/ write Example
  * @retval None
  */
void MX_NFC4_I2C_RW_DATA_Process(void)
{
	ndefMessage      message;
  uint16_t         rawMessageLen;
//  ndefBuffer       bufRawMessage;
  ndefConstBuffer  bufConstRawMessage;
  ReturnCode       err;

		  /* Reset Mailbox enable to allow write to EEPROM */
  NFC04A1_NFCTAG_ResetMBEN_Dyn(NFC04A1_NFCTAG_INSTANCE);

  NfcTag_SelectProtocol(NFCTAG_TYPE5);

  /* Check if no NDEF detected, init mem in Tag Type 5 */
  if( NfcType5_NDEFDetection( ) != NDEF_OK )
  {
    CCFileStruct.MagicNumber = NFCT5_MAGICNUMBER_E1_CCFILE;
    CCFileStruct.Version = NFCT5_VERSION_V1_0;
    CCFileStruct.MemorySize = ( ST25DV_MAX_SIZE / 8 ) & 0xFF;
    CCFileStruct.TT5Tag = 0x00;		//CL: Recomemnded to set to0 for better compatibility 
    /* Init of the Type Tag 5 component  */
    while( NfcType5_TT5Init( ) != NFCTAG_OK );
  }	

	NfcType5_ReadNDEF(rawMessageBuf);   
  
	NfcType5_GetLength(&rawMessageLen);	
//  bufRawMessage.buffer = rawMessageBuf;
//  bufRawMessage.length = rawMessageLen;
//	
//	if(verbose==true) 
//	{
//		ndefBufferDump("\n\rNDEF Content", (ndefConstBuffer*)&bufRawMessage, verbose);		
//	}
	
	bufConstRawMessage.buffer = rawMessageBuf;
  bufConstRawMessage.length = rawMessageLen;
  err = ndefMessageDecode(&bufConstRawMessage, &message);

  if( err != ERR_NONE )
  {
     platformLog("NDEF message cannot be decoded (ndefMessageDecode  returns %d)\r\n", err);	
		 return;
   }
   err = ndefMessageDump(&message, verbose); 
   if( err != ERR_NONE )
   {
      platformLog("NDEF message cannot be displayed (ndefMessageDump returns %d)\r\n", err);
			return;
   }			

 }


#ifdef __cplusplus
}
#endif


/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
